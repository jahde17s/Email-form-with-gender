from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic.base import TemplateView

def functionview(request):
    template_name = "jhade\exam.html"
    context = {'info': "CONTACT US FUNCION VIEW"}
    return render (request, template_name, context)


class classview(TemplateView):
    template_name= "jhade\cpage.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['info'] = "CONTACT US CLASS BASE"
        return context