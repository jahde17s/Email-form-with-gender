from django.urls import path
from django.urls import path

from . import views 
from jhade.views import classview 
app_name = 'jhade'
urlpatterns = [
    path('function', views.functionview, name= 'functionview'),
     path('class', classview.as_view(), name= 'classview'),
]